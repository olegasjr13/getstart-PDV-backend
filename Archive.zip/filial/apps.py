from django.apps import AppConfig


class FilialConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'filial'
