from .motivo_desconto_models import MotivoDesconto

__all__ = [
    "MotivoDesconto",
]