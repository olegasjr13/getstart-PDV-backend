from .tenants_models import Tenant, Domain
